public class Conjugaison {

    /* Écrivez vos fonctions ici */

    public static void main(String[] args) {

        /* Écrivez vos tests ici */

    }
}
